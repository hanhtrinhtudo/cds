import { apiClient } from "./apiClient";
import { News } from "../types";
import { isLegacyAppsScriptAuthMode } from "./authService";
import { cdsLegacyService } from "./cdsLegacyService";

export const newsService = {
  async getNews(): Promise<News[]> {
    if (isLegacyAppsScriptAuthMode()) return cdsLegacyService.getNews();
    return apiClient.get<News[]>("/api/news");
  },

  async getNewsById(id: string): Promise<News> {
    if (isLegacyAppsScriptAuthMode()) {
      const news = await cdsLegacyService.getNews();
      const item = news.find(n => n.id === id);
      if (!item) throw new Error("Không tìm thấy bản tin CDS legacy");
      return item;
    }
    return apiClient.get<News>(`/api/news/${id}`);
  },

  async createNews(data: Partial<News>): Promise<News> {
    return apiClient.post<News>("/api/news", data);
  },

  async updateNews(id: string, data: Partial<News>): Promise<News> {
    return apiClient.patch<News>(`/api/news/${id}`, data);
  },

  async deleteNews(id: string): Promise<{ message: string }> {
    return apiClient.delete<{ message: string }>(`/api/news/${id}`);
  }
};
export default newsService;
