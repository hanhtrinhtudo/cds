import { apiClient } from "./apiClient";
import { LearningTopic, LearningProgress, LearningAssignment, LearningStatus } from "../types";
import { isLegacyAppsScriptAuthMode } from "./authService";
import { cdsLegacyService } from "./cdsLegacyService";

export const learningService = {
  async getTopics(): Promise<LearningTopic[]> {
    if (isLegacyAppsScriptAuthMode()) return cdsLegacyService.getMaterials();
    return apiClient.get<LearningTopic[]>("/api/learning/topics");
  },

  async getTopicById(id: string): Promise<LearningTopic & { sections: any[]; progress: LearningProgress | null }> {
    if (isLegacyAppsScriptAuthMode()) {
      const topics = await cdsLegacyService.getMaterials();
      const topic = topics.find(t => t.id === id) || topics[0];
      const progress = cdsLegacyService.getProgress().find(p => p.topicId === topic.id) || null;
      return { ...topic, sections: cdsLegacyService.getSections().filter(section => section.topicId === topic.id), progress };
    }
    return apiClient.get<LearningTopic & { sections: any[]; progress: LearningProgress | null }>(`/api/learning/topics/${id}`);
  },

  async createTopic(data: Partial<LearningTopic>): Promise<LearningTopic> {
    return apiClient.post<LearningTopic>("/api/learning/topics", data);
  },

  async updateTopic(id: string, data: Partial<LearningTopic>): Promise<LearningTopic> {
    return apiClient.patch<LearningTopic>(`/api/learning/topics/${id}`, data);
  },

  async assignTopic(id: string, assignment: { assignedUnitIds: string[]; assignedUserIds?: string[]; deadline?: string; required?: boolean }): Promise<{ message: string; topic: LearningTopic }> {
    return apiClient.post<{ message: string; topic: LearningTopic }>(`/api/learning/topics/${id}/assign`, assignment);
  },

  async getMyAssignments(): Promise<LearningAssignment[]> {
    if (isLegacyAppsScriptAuthMode()) return [];
    return apiClient.get<LearningAssignment[]>("/api/learning/my-assignments");
  },

  async startProgress(topicId: string): Promise<LearningProgress> {
    if (isLegacyAppsScriptAuthMode()) {
      return {
        id: `legacy_progress_${topicId}`,
        userId: "legacy_user",
        topicId,
        status: LearningStatus.IN_PROGRESS,
        progressPercent: 10,
        startedAt: new Date().toISOString(),
        lastAccessedAt: new Date().toISOString(),
        needReview: false
      };
    }
    return apiClient.post<LearningProgress>("/api/learning/progress/start", { topicId });
  },

  async updateProgress(topicId: string, progressPercent: number, status: LearningStatus, needReview = false): Promise<LearningProgress> {
    if (isLegacyAppsScriptAuthMode()) {
      return {
        id: `legacy_progress_${topicId}`,
        userId: "legacy_user",
        topicId,
        status,
        progressPercent,
        startedAt: new Date().toISOString(),
        completedAt: status === LearningStatus.COMPLETED ? new Date().toISOString() : undefined,
        lastAccessedAt: new Date().toISOString(),
        needReview
      };
    }
    return apiClient.post<LearningProgress>("/api/learning/progress/update", { topicId, progressPercent, status, needReview });
  },

  async completeProgress(topicId: string): Promise<LearningProgress> {
    return apiClient.post<LearningProgress>("/api/learning/progress/complete", { topicId });
  }
};
export default learningService;
