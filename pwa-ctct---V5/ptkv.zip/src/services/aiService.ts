import { apiClient } from "./apiClient";
import { AIChatMessage } from "../types";

export const aiService = {
  async getChatHistory(): Promise<AIChatMessage[]> {
    return apiClient.get<AIChatMessage[]>("/api/ai/chat/history");
  },

  async sendMessage(message: string, topicContext?: any, isLawContext?: boolean): Promise<{ content: string }> {
    return apiClient.post<{ content: string }>("/api/ai/chat/message", {
      message,
      topicContext,
      isLawContext
    });
  }
};
export default aiService;
