import { apiClient } from "./apiClient";
import { Exam, ExamAttempt, Question } from "../types";
import { isLegacyAppsScriptAuthMode } from "./authService";
import { cdsLegacyService } from "./cdsLegacyService";

export const examService = {
  async getExamHistory(): Promise<ExamAttempt[]> {
    if (isLegacyAppsScriptAuthMode()) return cdsLegacyService.getExamHistory();
    return apiClient.get<ExamAttempt[]>("/api/exam-attempts/history");
  },
  async getExams(): Promise<Exam[]> {
    if (isLegacyAppsScriptAuthMode()) return [await cdsLegacyService.getOfficialExam(), await cdsLegacyService.getTryExam()];
    return apiClient.get<Exam[]>("/api/exams");
  },

  async getExamById(id: string): Promise<Exam & { questions: Question[] }> {
    if (isLegacyAppsScriptAuthMode()) {
      const exams = [await cdsLegacyService.getOfficialExam(), await cdsLegacyService.getTryExam()];
      const exam = exams.find(e => e.id === id) || exams[0];
      const questions = await cdsLegacyService.getQuestions();
      return { ...exam, questions };
    }
    return apiClient.get<Exam & { questions: Question[] }>(`/api/exams/${id}`);
  },

  async createExam(data: Partial<Exam>): Promise<Exam> {
    return apiClient.post<Exam>("/api/exams", data);
  },

  async updateExam(id: string, data: Partial<Exam>): Promise<Exam> {
    return apiClient.patch<Exam>(`/api/exams/${id}`, data);
  },

  async startExam(examId: string): Promise<ExamAttempt> {
    return apiClient.post<ExamAttempt>("/api/exam-attempts/start", { examId });
  },

  async submitExam(attemptId: string, answers: { [questionId: string]: number[] }): Promise<{ attempt: ExamAttempt; passed: boolean; score: number }> {
    return apiClient.post<{ attempt: ExamAttempt; passed: boolean; score: number }>("/api/exam-attempts/submit", { attemptId, answers });
  }
};
export default examService;
