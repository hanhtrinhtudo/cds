import React, { useState } from "react";
import { News } from "../types";
import { BookOpen, ArrowLeft, Calendar, User, Eye, Share2, Sparkles, MessageSquare, ChevronRight } from "lucide-react";

interface NewsCenterProps {
  news: News[];
  activeNewsArg: News | null;
  onClearNewsArg: () => void;
  onNavigate: (tab: string, arg?: any) => void;
}

export default function NewsCenter({ news, activeNewsArg, onClearNewsArg, onNavigate }: NewsCenterProps) {
  const [selectedNews, setSelectedNews] = useState<News | null>(activeNewsArg);
  const [newsCategory, setNewsCategory] = useState<string>("All");

  React.useEffect(() => {
    if (activeNewsArg) {
      setSelectedNews(activeNewsArg);
    }
  }, [activeNewsArg]);

  const categories = [
    "All",
    "Tin theo thời gian",
    "Tin trong ngày",
    "Tin chính trị ĐCSVN",
    "Chính sách mới",
    "Phổ biến giáo dục pháp luật",
    "Tra cứu văn bản chính sách"
  ];

  const handleBackToList = () => {
    setSelectedNews(null);
    onClearNewsArg();
  };

  const filteredNews = news.filter(item => 
    newsCategory === "All" || item.category === newsCategory
  );

  if (selectedNews) {
    return (
      <div className="space-y-4 animate-fade-in" id="news-detail-view-layout">
        {/* Sticky back bar with high-contrast touch targets */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <button
            onClick={handleBackToList}
            className="flex items-center gap-1.5 text-xs font-black text-emerald-800 hover:text-emerald-950 transition cursor-pointer"
          >
            <ArrowLeft size={16} />
            <span>QUAY LẠI BẢN TIN</span>
          </button>
          <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wide">{selectedNews.category}</span>
        </div>

        {/* Detailed article card */}
        <div className="bg-white border border-slate-100 rounded-[24px] shadow-sm overflow-hidden">
          {/* Header Image cover */}
          <div className="h-44 bg-slate-900 relative">
            {selectedNews.imageUrl ? (
              <img src={selectedNews.imageUrl} alt={selectedNews.title} className="w-full h-full object-cover opacity-75" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 bg-emerald-900/40">
                <BookOpen size={36} />
                <p className="text-[10px] font-black mt-1.5 uppercase tracking-widest text-emerald-100/65">Tin tức nội bộ</p>
              </div>
            )}
            <div className="absolute bottom-3 left-4 right-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-1 rounded-lg">
              <h1 className="text-xs font-black text-white leading-snug drop-shadow-md">
                {selectedNews.title}
              </h1>
            </div>
          </div>

          <div className="p-4.5 space-y-4">
            {/* Meta tags bar */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[9px] text-slate-400 border-b border-slate-50 pb-3 font-extrabold uppercase">
              <span className="flex items-center gap-1">
                <Calendar size={11} />
                <span>{new Date(selectedNews.publishedAt).toLocaleDateString("vi-VN")}</span>
              </span>
              <span className="flex items-center gap-1">
                <User size={11} />
                <span>Ban Biên Tập</span>
              </span>
              <span className="flex items-center gap-1">
                <Eye size={11} />
                <span>Nội bộ</span>
              </span>
            </div>

            {/* Structured Executive Summary box */}
            <p className="text-[11px] font-bold text-slate-700 bg-slate-50 p-3.5 border-l-4 border-emerald-800 rounded-r-xl leading-relaxed">
              {selectedNews.summary}
            </p>

            {/* Clean article copy text block */}
            <div className="text-[11px] text-slate-600 leading-relaxed whitespace-pre-line space-y-3 font-medium" id="news-full-content-box">
              {selectedNews.content || "Nội dung đang được cập nhật qua mạng quân khu bảo mật..."}
            </div>

            {/* Smart actions row */}
            <div className="pt-4 border-t border-slate-50 flex flex-col gap-2">
              <button
                onClick={() => onNavigate("aitutor", {
                  title: `Góc nhìn bản tin: ${selectedNews.title}`,
                  category: selectedNews.category,
                  description: selectedNews.summary
                })}
                className="w-full py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs rounded-xl transition shadow-sm flex items-center justify-center gap-1.5 cursor-pointer min-h-[44px]"
              >
                <Sparkles size={13} className="text-yellow-400 fill-current" />
                <span>Phân tích góc nhìn Lý luận cùng AI</span>
              </button>

              <button
                type="button"
                onClick={() => alert("Đã sao chép liên kết bài viết nội bộ đơn vị!")}
                className="w-full py-2.5 bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer min-h-[40px]"
              >
                <Share2 size={13} />
                <span>Sao chép liên kết bản tin</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" id="news-center-tab-content">
      {/* Scrollable Horizontal Category Chips */}
      <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm space-y-1.5">
        <label className="text-[9px] font-black uppercase tracking-wider text-slate-400 pl-1">Phân loại bản tin</label>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setNewsCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-[10px] font-bold whitespace-nowrap border shrink-0 transition cursor-pointer min-h-[32px] ${
                newsCategory === cat
                  ? "bg-emerald-800 text-white border-emerald-800 shadow-sm"
                  : "bg-slate-50 text-slate-500 border-slate-200/60 hover:bg-slate-100"
              }`}
            >
              {cat === "All" ? "Tất cả tin" : cat}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-red-50 border border-red-100 rounded-2xl p-3 text-xs text-red-900 space-y-1">
        <p className="font-black uppercase">Phổ biến giáo dục pháp luật / Tra cứu văn bản chính sách</p>
        <p className="text-[10px] leading-relaxed">
          Kế thừa từ CDS tintuc24.html: tin theo thời gian, tin trong ngày, tin chính trị ĐCSVN, chính sách mới và tra cứu văn bản chính sách.
        </p>
      </div>

      {/* Vertical mobile news feed */}
      <div className="space-y-3" id="news-grid-list">
        {filteredNews.map(item => (
          <div
            key={item.id}
            onClick={() => setSelectedNews(item)}
            className="bg-white border border-slate-100 rounded-[24px] shadow-sm overflow-hidden hover:border-emerald-200 transition cursor-pointer flex flex-col justify-between active:scale-99"
          >
            <div>
              {/* Image banner with floating badge */}
              <div className="h-32 bg-slate-950 relative">
                {item.imageUrl ? (
                  <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover opacity-75" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-500 bg-emerald-900/20">
                    <BookOpen size={24} />
                  </div>
                )}
                <span className="absolute top-3 left-3 px-2 py-0.5 bg-emerald-800 text-white font-black rounded-full text-[8px] uppercase tracking-wide shadow-sm border border-emerald-700">
                  {item.category}
                </span>
              </div>

              {/* Body */}
              <div className="p-4 space-y-1">
                <p className="text-[8px] text-slate-400 font-extrabold uppercase font-mono">{new Date(item.publishedAt).toLocaleDateString("vi-VN")}</p>
                <h4 className="text-xs font-black text-slate-800 line-clamp-1 leading-snug">
                  {item.title}
                </h4>
                <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                  {item.summary}
                </p>
              </div>
            </div>

            <div className="px-4 pb-3 pt-2 border-t border-slate-50 flex items-center justify-between text-[10px] font-black text-emerald-800">
              <span>ĐỌC BẢN TIN</span>
              <ChevronRight size={12} />
            </div>
          </div>
        ))}
        {filteredNews.length === 0 && (
          <div className="bg-white border border-dashed border-slate-200 rounded-[24px] p-6 text-center text-xs text-slate-500">
            Không có tin trong nhóm này. Hãy chọn “Tất cả tin” hoặc cấu hình nguồn Apps Script legacy bằng VITE_LEGACY_NEWS_API_URL.
          </div>
        )}
      </div>
    </div>
  );
}
