import React from "react";
import { User, LearningTopic, LearningProgress, Exam, News, LearningStatus, ExamAttempt } from "../types";
import { BookOpen, Calendar, Award, AlertTriangle, ChevronRight, MessageSquare, HelpCircle, Flame, Star } from "lucide-react";

interface DashboardProps {
  user: User;
  topics: LearningTopic[];
  progress: LearningProgress[];
  exams: Exam[];
  examAttempts: ExamAttempt[];
  news: News[];
  onNavigate: (tab: string, arg?: any) => void;
  streak: number;
  averageScore: number;
}

export default function Dashboard({
  user,
  topics,
  progress,
  exams,
  examAttempts,
  news,
  onNavigate,
  streak,
  averageScore
}: DashboardProps) {

  // Resolve user specific progress and topics
  const getTopicProgress = (topicId: string) => {
    return progress.find(p => p.userId === user.id && p.topicId === topicId);
  };

  // Determine the highest priority task for "Hôm nay tôi cần học gì?"
  // Logic:
  // 1. Official exam active and not yet submitted
  // 2. Assigned topic that is REQUIRED and not started
  // 3. Topic marked "need review" (status = NEED_REVIEW)
  // 4. Required topic in progress
  // 5. Recommended optional topic
  
  const getPriorityTask = () => {
    // 1. Active, uncompleted exam
    const activeExam = exams.find(e => {
      if (e.status !== "active") return false;
      const submitted = examAttempts && examAttempts.some(att => att.userId === user.id && att.examId === e.id);
      return !submitted;
    });

    if (activeExam) {
      return {
        type: "exam",
        title: "Kỳ thi chính thức đang diễn ra!",
        description: activeExam.title,
        detail: `Thời gian: ${activeExam.durationMinutes} phút. Hạn chót: ${new Date(activeExam.endDate).toLocaleDateString("vi-VN")}`,
        actionText: "Vào phòng thi ngay",
        target: "exams",
        targetArg: activeExam,
        badgeColor: "bg-red-100 text-red-800 border-red-200",
        badgeText: "ƯU TIÊN 1 - THI CỬ"
      };
    }

    // 2. Required topic - not started
    const notStartedRequired = topics.find(t => {
      if (!t.required) return false;
      const prog = getTopicProgress(t.id);
      return !prog || prog.status === LearningStatus.NOT_STARTED;
    });

    if (notStartedRequired) {
      return {
        type: "topic",
        title: "Chủ đề học tập bắt buộc chưa học",
        description: notStartedRequired.title,
        detail: `Ước tính: ${notStartedRequired.estimatedMinutes} phút • Thời hạn: ${notStartedRequired.deadline ? new Date(notStartedRequired.deadline).toLocaleDateString("vi-VN") : "Không có"}`,
        actionText: "Bắt đầu học ngay",
        target: "learning",
        targetArg: notStartedRequired,
        badgeColor: "bg-amber-100 text-amber-800 border-amber-200",
        badgeText: "ƯU TIÊN 2 - CHƯA HỌC"
      };
    }

    // 3. Topic marked "need review"
    const needReviewTopic = topics.find(t => {
      const prog = getTopicProgress(t.id);
      return prog && prog.status === LearningStatus.NEED_REVIEW;
    });

    if (needReviewTopic) {
      return {
        type: "review",
        title: "Chủ đề cần ôn tập gấp",
        description: needReviewTopic.title,
        detail: "Đồng chí đạt điểm thấp trong bài trắc nghiệm tự luyện trước đó.",
        actionText: "Ôn tập lại chuyên đề",
        target: "learning",
        targetArg: needReviewTopic,
        badgeColor: "bg-orange-100 text-orange-800 border-orange-200",
        badgeText: "ƯU TIÊN 3 - CẦN ÔN TẬP"
      };
    }

    // 4. Required topic - in progress
    const inProgressRequired = topics.find(t => {
      if (!t.required) return false;
      const prog = getTopicProgress(t.id);
      return prog && prog.status === LearningStatus.IN_PROGRESS;
    });

    if (inProgressRequired) {
      const prog = getTopicProgress(inProgressRequired.id);
      return {
        type: "topic",
        title: "Tiếp tục chủ đề đang học dở",
        description: inProgressRequired.title,
        detail: `Tiến độ hiện tại: ${prog?.progressPercent}% • Ước tính: ${inProgressRequired.estimatedMinutes} phút`,
        actionText: "Học tiếp bài giảng",
        target: "learning",
        targetArg: inProgressRequired,
        badgeColor: "bg-blue-100 text-blue-800 border-blue-200",
        badgeText: "ƯU TIÊN 4 - ĐANG HỌC"
      };
    }

    // 5. Recommended optional topic or general review
    const anyNotCompleted = topics.find(t => {
      const prog = getTopicProgress(t.id);
      return !prog || prog.status !== LearningStatus.COMPLETED;
    });

    if (anyNotCompleted) {
      return {
        type: "topic",
        title: "Bài giảng tự chọn đề xuất",
        description: anyNotCompleted.title,
        detail: `Chuyên mục: ${anyNotCompleted.category}`,
        actionText: "Tìm hiểu bài đọc",
        target: "learning",
        targetArg: anyNotCompleted,
        badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200",
        badgeText: "ĐỀ XUẤT HỌC"
      };
    }

    // 6. Complete
    return {
      type: "done",
      title: "Hoàn thành xuất sắc nhiệm vụ học tập!",
      description: "Đồng chí đã hoàn thành tất cả các chuyên đề giáo dục chính trị và pháp luật được giao hôm nay.",
      detail: "Hãy tham gia tự luyện trắc nghiệm ngẫu nhiên hoặc hỏi trợ lý AI để mở rộng kiến thức.",
      actionText: "Trò chuyện với Trợ lý AI",
      target: "aitutor",
      targetArg: null,
      badgeColor: "bg-green-100 text-green-800 border-green-200",
      badgeText: "HOÀN THÀNH"
    };
  };

  const priorityTask = getPriorityTask();

  // Stats calculation
  const totalAssigned = topics.filter(t => t.required).length;
  const completedAssigned = topics.filter(t => {
    if (!t.required) return false;
    const prog = getTopicProgress(t.id);
    return prog && prog.status === LearningStatus.COMPLETED;
  }).length;

  const completionRate = totalAssigned > 0 ? Math.round((completedAssigned / totalAssigned) * 100) : 100;

  // Weak topics list (scored need_review)
  const weakTopics = topics.filter(t => {
    const prog = getTopicProgress(t.id);
    return prog && prog.status === LearningStatus.NEED_REVIEW;
  });

  // Latest announcements
  const latestNotices = news.filter(n => n.category === "Thông báo đơn vị" || n.category === "Tin tức huấn luyện").slice(0, 2);
  const dashboardNotices = latestNotices.length > 0 ? latestNotices : news.slice(0, 3);

  return (
    <div className="space-y-3" id="dashboard-tab-content">
      {/* Dynamic Banner Greeting */}
      <div className="bg-gradient-to-br from-emerald-800 via-emerald-900 to-emerald-950 p-3.5 rounded-2xl text-white shadow-sm relative overflow-hidden" id="dashboard-banner">
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none transform translate-y-4 translate-x-3">
          <BookOpen size={104} />
        </div>
        <div className="space-y-2.5 relative">
          <div>
            <span className="inline-flex max-w-full items-center gap-1 px-2.5 py-0.5 bg-emerald-300 text-slate-950 font-black rounded-full text-[9px] uppercase tracking-wide animate-pulse shadow-sm">
              <Flame size={11} fill="currentColor" className="shrink-0" />
              <span>Đồng hành {streak} ngày liên tục</span>
            </span>
            <h2 className="text-xl font-extrabold tracking-tight mt-2.5">Chào đồng chí,</h2>
            <p className="text-base font-bold text-emerald-300 leading-snug break-words">{user.fullName}</p>
            <p className="text-[10px] text-emerald-100/90 mt-0.5 max-w-xs leading-snug">
              Hôm nay là {new Date().toLocaleDateString("vi-VN", { weekday: 'long', day: 'numeric', month: 'numeric' })}. Cùng hoàn thành các nhiệm vụ chính trị xuất sắc!
            </p>
          </div>

          <div className="flex items-center gap-2 bg-emerald-950/60 backdrop-blur-sm px-3 py-1.5 rounded-xl border border-white/10">
            <div className="flex-1 text-center">
              <p className="text-[9px] text-emerald-200 uppercase font-extrabold tracking-wider">Hoàn thành bài</p>
              <p className="text-lg leading-none font-black text-amber-300 mt-0.5">{completionRate}%</p>
            </div>
            <div className="w-px h-7 bg-white/20"></div>
            <div className="flex-1 text-center">
              <p className="text-[9px] text-emerald-200 uppercase font-extrabold tracking-wider">Điểm tự luyện</p>
              <p className="text-lg leading-none font-black text-white mt-0.5">{averageScore.toFixed(1)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* CORE DAILY QUESTION SECTION - "Hôm nay tôi cần học gì?" */}
      <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm space-y-2.5" id="priority-task-box">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Nhiệm vụ trọng tâm</h3>
          <span className={`px-2 py-0.5 border text-[8px] leading-tight font-extrabold rounded-full uppercase tracking-wide text-right shrink-0 max-w-[52%] ${priorityTask.badgeColor}`}>
            {priorityTask.badgeText}
          </span>
        </div>
        
        <div className="flex items-start gap-2.5 p-2.5 bg-slate-50 border border-slate-100 rounded-xl">
          <div className={`p-2 rounded-xl shrink-0 ${
            priorityTask.type === "exam" ? "bg-red-50 text-red-600 border border-red-100" :
            priorityTask.type === "review" ? "bg-orange-50 text-orange-600 border border-orange-100" :
            "bg-emerald-50 text-emerald-600 border border-emerald-100"
          }`}>
            {priorityTask.type === "exam" ? <Calendar size={18} /> : <BookOpen size={18} />}
          </div>
          <div className="flex-1 min-w-0 space-y-0.5">
            <h4 className="text-[9px] font-bold text-slate-400 uppercase tracking-wide leading-snug">{priorityTask.title}</h4>
            <p className="text-xs font-bold text-slate-800 leading-snug">{priorityTask.description}</p>
            <p className="text-[10px] text-slate-500 font-medium leading-snug">
              {priorityTask.detail}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate(priorityTask.target, priorityTask.targetArg)}
          className={`w-full py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition shadow-sm active:scale-95 cursor-pointer min-h-[42px] ${
            priorityTask.type === "exam" ? "bg-red-600 hover:bg-red-700 text-white" :
            priorityTask.type === "review" ? "bg-orange-600 hover:bg-orange-700 text-white" :
            "bg-emerald-800 hover:bg-emerald-900 text-white"
          }`}
          id="btn-priority-task-action"
        >
          <span>{priorityTask.actionText}</span>
          <ChevronRight size={14} />
        </button>
      </div>

      {/* QUICK ACTIONS ROW */}
      <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm space-y-2.5" id="quick-actions">
        <h4 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Lối tắt thao tác nhanh</h4>
        <div className="grid grid-cols-2 gap-2">
          
          <button
            onClick={() => onNavigate("aitutor")}
            className="p-2.5 bg-slate-50 hover:bg-emerald-50 active:scale-95 border border-transparent hover:border-emerald-100 rounded-xl text-left transition flex items-center gap-2 cursor-pointer min-h-[44px]"
          >
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl shrink-0">
              <MessageSquare size={16} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">Hỏi Trợ lý AI</p>
              <p className="text-[9px] text-slate-400 truncate">Giải thích điều luật nhanh</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate("quiz")}
            className="p-2.5 bg-slate-50 hover:bg-emerald-50 active:scale-95 border border-transparent hover:border-emerald-100 rounded-xl text-left transition flex items-center gap-2 cursor-pointer min-h-[44px]"
          >
            <div className="p-2 bg-blue-100 text-blue-800 rounded-xl shrink-0">
              <HelpCircle size={16} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">Tự luyện tập</p>
              <p className="text-[9px] text-slate-400 truncate">Trắc nghiệm ngẫu nhiên</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate("legal")}
            className="p-2.5 bg-slate-50 hover:bg-emerald-50 active:scale-95 border border-transparent hover:border-emerald-100 rounded-xl text-left transition flex items-center gap-2 cursor-pointer min-h-[44px]"
          >
            <div className="p-2 bg-amber-100 text-amber-800 rounded-xl shrink-0">
              <BookOpen size={16} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">Học Pháp luật</p>
              <p className="text-[9px] text-slate-400 truncate">Tình huống và văn bản</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate("ranking")}
            className="p-2.5 bg-slate-50 hover:bg-emerald-50 active:scale-95 border border-transparent hover:border-emerald-100 rounded-xl text-left transition flex items-center gap-2 cursor-pointer min-h-[44px]"
          >
            <div className="p-2 bg-yellow-100 text-yellow-800 rounded-xl shrink-0">
              <Award size={16} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">Thi đua đồng chí</p>
              <p className="text-[9px] text-slate-400 truncate">Xem bảng xếp hạng đơn vị</p>
            </div>
          </button>

        </div>
      </div>

      {/* WEAK TOPICS */}
      <div className="bg-white border border-slate-100 rounded-[24px] p-4.5 shadow-sm space-y-3" id="weak-topics-box">
        <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
          <AlertTriangle className="text-orange-500" size={16} />
          <span>Vùng kiến thức cần củng cố</span>
        </h3>
        
        {weakTopics.length > 0 ? (
          <div className="space-y-2">
            <p className="text-[11px] text-slate-500 leading-normal">
              Đồng chí trả lời đúng dưới 60% số câu hỏi trong các bài tự luyện sau:
            </p>
            {weakTopics.map(t => (
              <div key={t.id} className="p-3 bg-orange-50/70 border border-orange-100 rounded-xl flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-1.5 h-1.5 bg-orange-500 rounded-full shrink-0" />
                  <p className="font-bold text-slate-800 truncate">{t.title}</p>
                </div>
                <button
                  onClick={() => onNavigate("learning", t)}
                  className="text-orange-800 text-[10px] font-black shrink-0 flex items-center hover:underline cursor-pointer"
                >
                  <span>Ôn lại</span>
                  <ChevronRight size={10} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-4 text-center text-slate-400 flex flex-col items-center gap-1 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <Star size={24} className="text-amber-400 fill-amber-400" />
            <p className="text-xs font-bold text-slate-700">Rất tốt! Không có chủ đề bị yếu</p>
            <p className="text-[9px] text-slate-400">Đồng chí hãy duy trì kết quả xuất sắc này.</p>
          </div>
        )}
      </div>

      {/* LATEST NOTICES / NEWS */}
      <div className="bg-white border border-slate-100 rounded-[24px] p-4.5 shadow-sm space-y-3" id="notices-box">
        <div className="flex items-center justify-between pb-1 border-b border-slate-50">
          <h3 className="text-xs font-bold text-slate-800">Thông báo & Sự kiện nổi bật</h3>
          <button onClick={() => onNavigate("news")} className="text-[10px] text-emerald-800 font-extrabold hover:underline flex items-center gap-0.5 cursor-pointer">
            <span>Tất cả</span>
            <ChevronRight size={12} />
          </button>
        </div>
        <div className="space-y-2.5">
          {dashboardNotices.map(notice => (
            <div
              key={notice.id}
              onClick={() => onNavigate("news_detail", notice)}
              className="group cursor-pointer flex gap-3 p-2 bg-slate-50 hover:bg-emerald-50/30 rounded-2xl transition border border-transparent hover:border-emerald-100/30"
            >
              <div className="shrink-0 w-16 h-14 bg-slate-200 rounded-xl overflow-hidden relative border border-slate-300/40">
                {notice.imageUrl ? (
                  <img src={notice.imageUrl} alt={notice.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400 bg-slate-100">
                    <BookOpen size={16} />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0 flex flex-col justify-center">
                <span className="inline-block px-1.5 py-0.5 bg-emerald-50 text-emerald-800 text-[8px] font-black rounded w-fit mb-0.5 uppercase tracking-wide">
                  {notice.category}
                </span>
                <h4 className="text-[11px] font-bold text-slate-800 group-hover:text-emerald-800 transition line-clamp-1 leading-snug">
                  {notice.title}
                </h4>
                <p className="text-[9px] text-slate-400 line-clamp-1 mt-0.5">
                  {notice.summary}
                </p>
              </div>
            </div>
          ))}
          {dashboardNotices.length === 0 && (
            <button
              onClick={() => onNavigate("news")}
              className="w-full p-3 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-left text-xs font-bold text-slate-600"
            >
              Tin tức và phổ biến giáo dục pháp luật đã sẵn sàng khi cấu hình dữ liệu CDS legacy.
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
