import React, { useState, useEffect } from "react";
import { User, Exam, ExamAttempt, Question, QuestionType } from "../types";
import { Award, Timer, CheckCircle, AlertTriangle, ArrowLeft, ChevronRight, FileText, ClipboardList } from "lucide-react";

interface OfficialExamProps {
  user: User;
  exams: Exam[];
  attempts: ExamAttempt[];
  allQuestions: Question[];
  onSaveExamAttempt: (attempt: ExamAttempt) => void;
  activeExamArg: Exam | null;
  onClearExamArg: () => void;
  onNavigate: (tab: string, arg?: any) => void;
}

export default function OfficialExam({
  user,
  exams,
  attempts,
  allQuestions,
  onSaveExamAttempt,
  activeExamArg,
  onClearExamArg,
  onNavigate
}: OfficialExamProps) {
  // Config state
  const [examMode, setExamMode] = useState<"list" | "runner" | "result">("list");
  const [selectedExam, setSelectedExam] = useState<Exam | null>(activeExamArg);
  const [activeAttempt, setActiveAttempt] = useState<ExamAttempt | null>(null);

  // Runner questions & answers
  const [examQuestions, setExamQuestions] = useState<Question[]>([]);
  const [runnerAnswers, setRunnerAnswers] = useState<{ [qId: string]: number[] }>({});
  const [currentQIdx, setCurrentQIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0); // in seconds
  const [confirmSubmitModal, setConfirmSubmitModal] = useState(false);

  // Sync props navigation triggers
  useEffect(() => {
    if (activeExamArg) {
      setSelectedExam(activeExamArg);
      // check if already attempted
      const alreadyAttempted = attempts.find(a => a.userId === user.id && a.examId === activeExamArg.id);
      if (alreadyAttempted) {
        setExamMode("result");
      } else {
        handleStartExam(activeExamArg);
      }
    }
  }, [activeExamArg]);

  // Countdown timer effect
  useEffect(() => {
    if (examMode !== "runner" || timeLeft <= 0) {
      if (timeLeft === 0 && examMode === "runner") {
        // Auto submit when time runs out
        handleSubmitExam(true);
      }
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, examMode]);

  const handleStartExam = (exam: Exam) => {
    // Check if expired
    if (exam.status === "expired" || new Date(exam.endDate) < new Date()) {
      alert("Đợt sát hạch này đã hết hạn, không thể bắt đầu.");
      return;
    }

    // Filter questions based on exam's associated topicIds
    const pool = allQuestions.filter(q => exam.topicIds.includes(q.topicId));
    // Pick required count or fallback
    const selected = pool.slice(0, exam.questionCount);

    setExamQuestions(selected);
    setRunnerAnswers({});
    setCurrentQIdx(0);
    setTimeLeft(exam.durationMinutes * 60);
    setSelectedExam(exam);
    setExamMode("runner");

    // Initialize temporary attempt in progress state
    const newAttempt: ExamAttempt = {
      id: "ea_" + Date.now(),
      examId: exam.id,
      userId: user.id,
      startedAt: new Date().toISOString(),
      score: 0,
      correctCount: 0,
      wrongCount: 0,
      passed: false,
      status: "in_progress",
      answers: {}
    };
    setActiveAttempt(newAttempt);
  };

  const handleOptionSelect = (qId: string, optIdx: number, type: QuestionType) => {
    setRunnerAnswers(prev => {
      const current = prev[qId] || [];
      if (type === QuestionType.SINGLE || type === QuestionType.TRUE_FALSE || type === QuestionType.SCENARIO) {
        return { ...prev, [qId]: [optIdx] };
      } else {
        // multiple choice
        const updated = current.includes(optIdx)
          ? current.filter(i => i !== optIdx)
          : [...current, optIdx];
        return { ...prev, [qId]: updated };
      }
    });
  };

  const handleSubmitExam = (force = false) => {
    if (!selectedExam || !activeAttempt) return;

    if (!force && !confirmSubmitModal) {
      setConfirmSubmitModal(true);
      return;
    }

    // Evaluate score
    let correctCount = 0;
    examQuestions.forEach(q => {
      const chosen = runnerAnswers[q.id] || [];
      const isCorrect = q.correctAnswers.length === chosen.length &&
        q.correctAnswers.every(idx => chosen.includes(idx));
      if (isCorrect) correctCount++;
    });

    const wrongCount = examQuestions.length - correctCount;
    // Calculate final score scaled out of 10
    const finalScore = Number(((correctCount / examQuestions.length) * 10).toFixed(1));
    const passed = finalScore >= selectedExam.passingScore;

    const finishedAttempt: ExamAttempt = {
      ...activeAttempt,
      submittedAt: new Date().toISOString(),
      score: finalScore,
      correctCount: correctCount,
      wrongCount: wrongCount,
      passed: passed,
      status: "submitted",
      answers: runnerAnswers
    };

    onSaveExamAttempt(finishedAttempt);
    setActiveAttempt(finishedAttempt);
    setConfirmSubmitModal(false);
    setExamMode("result");
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const getUserAttempt = (examId: string) => {
    return attempts.find(a => a.userId === user.id && a.examId === examId);
  };

  const handleBackToList = () => {
    setSelectedExam(null);
    setExamMode("list");
    onClearExamArg();
  };

  if (examMode === "runner" && selectedExam) {
    const currentQ = examQuestions[currentQIdx];
    const isAnswered = runnerAnswers[currentQ.id]?.length > 0;

    return (
      <div className="space-y-4" id="exam-fullscreen-runner">
        {/* Sticky distraction-free header */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div className="min-w-0">
            <span className="inline-flex px-2 py-0.5 bg-red-50 text-red-700 text-[8px] font-black rounded uppercase tracking-wide">
              Đang Sát hạch chính quy
            </span>
            <h3 className="text-xs font-bold text-slate-800 line-clamp-1 mt-0.5">{selectedExam.title}</h3>
          </div>

          {/* TIMER COUNTDOWN */}
          <div className="flex items-center gap-1 bg-red-600 text-white px-3 py-1.5 rounded-xl font-mono font-black animate-pulse text-xs shrink-0 shadow-sm">
            <Timer size={13} />
            <span>{formatTime(timeLeft)}</span>
          </div>
        </div>

        {/* Auto-save & Status indicator */}
        <div className="flex items-center justify-between text-[9px] text-slate-400 font-extrabold px-1">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" />
            Tự động lưu bài làm...
          </span>
          <span>TIẾN ĐỘ: {Math.round(((currentQIdx + 1) / examQuestions.length) * 100)}%</span>
        </div>

        {/* Question card */}
        <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm space-y-4">
          <div className="space-y-1.5">
            <span className="inline-block px-1.5 py-0.5 bg-slate-100 text-slate-600 text-[8px] font-black rounded uppercase tracking-wide">
              Câu {currentQIdx + 1} của {examQuestions.length}
            </span>
            <h4 className="text-sm font-black text-slate-800 leading-snug">
              {currentQ.questionText}
            </h4>
          </div>

          {/* Answer Options - Min 48px touch target */}
          <div className="space-y-2.5">
            {currentQ.options.map((option, idx) => {
              const isSelected = runnerAnswers[currentQ.id]?.includes(idx) || false;
              return (
                <button
                  key={idx}
                  onClick={() => handleOptionSelect(currentQ.id, idx, currentQ.type)}
                  className={`w-full p-4 rounded-2xl text-left text-xs transition border cursor-pointer active:scale-98 min-h-[52px] ${
                    isSelected
                      ? "bg-red-50/50 border-red-500 text-red-950 font-bold shadow-sm"
                      : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100/60"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black shrink-0 ${
                      isSelected ? "bg-red-600 text-white" : "bg-white border text-slate-400"
                    }`}>
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="leading-snug pt-0.5">{option}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Navigation Controls with clear touch targets */}
          <div className="pt-3 border-t border-slate-50 flex items-center justify-between gap-3">
            <button
              onClick={() => setCurrentQIdx(prev => Math.max(0, prev - 1))}
              disabled={currentQIdx === 0}
              className="px-4 py-3 bg-slate-50 hover:bg-slate-100 disabled:opacity-40 text-slate-600 font-bold text-xs rounded-xl transition cursor-pointer min-h-[44px]"
            >
              Câu trước
            </button>

            {currentQIdx < examQuestions.length - 1 ? (
              <button
                onClick={() => setCurrentQIdx(prev => prev + 1)}
                className="px-4 py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition cursor-pointer min-h-[44px]"
              >
                Câu tiếp theo
              </button>
            ) : (
              <button
                onClick={() => setConfirmSubmitModal(true)}
                className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer min-h-[44px]"
                id="btn-exam-submit-trigger"
              >
                Nộp bài sát hạch
              </button>
            )}
          </div>
        </div>

        {/* Expandable MD3 Grid/Bottom sheet for jumping to any question */}
        <div className="bg-white border border-slate-100 rounded-[24px] p-4 shadow-sm space-y-2.5">
          <p className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400">Sơ đồ tiến độ bài thi</p>
          <div className="grid grid-cols-5 gap-1.5">
            {examQuestions.map((q, idx) => {
              const isQAnswered = runnerAnswers[q.id]?.length > 0;
              const isCurrent = currentQIdx === idx;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentQIdx(idx)}
                  className={`h-9 text-xs font-black rounded-xl flex items-center justify-center transition cursor-pointer border ${
                    isCurrent ? "bg-red-600 border-red-600 text-white shadow-sm" :
                    isQAnswered ? "bg-emerald-50 border-emerald-100 text-emerald-800" : "bg-slate-50 border-slate-100 text-slate-400"
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Submission Confirmation Dialog overlay */}
        {confirmSubmitModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white text-slate-800 rounded-[28px] max-w-sm w-full p-5 space-y-4 border border-slate-100 text-center animate-fade-in shadow-2xl">
              <div className="p-3.5 bg-red-50 text-red-600 rounded-full w-fit mx-auto border border-red-100">
                <AlertTriangle size={32} />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-black text-slate-800">Xác nhận nộp bài sát hạch?</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Đồng chí đã trả lời {Object.keys(runnerAnswers).length} trên tổng số {examQuestions.length} câu hỏi. Hãy kiểm tra thật kỹ trước khi nộp.</p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmSubmitModal(false)}
                  className="flex-1 py-3 bg-slate-50 hover:bg-slate-100 rounded-xl text-xs font-bold text-slate-600 cursor-pointer min-h-[44px]"
                >
                  Rà soát lại
                </button>
                <button
                  type="button"
                  onClick={() => handleSubmitExam(true)}
                  className="flex-1 py-3 bg-red-600 hover:bg-red-700 rounded-xl text-xs font-black text-white shadow-md cursor-pointer min-h-[44px]"
                  id="btn-exam-submit-confirm"
                >
                  Nộp bài ngay
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (examMode === "result" && selectedExam) {
    const attempt = getUserAttempt(selectedExam.id);

    return (
      <div className="space-y-4" id="exam-result-box">
        {/* Sticky back header */}
        <div className="bg-white border border-slate-100 rounded-2xl p-4.5 shadow-sm flex items-center justify-between">
          <button
            onClick={handleBackToList}
            className="flex items-center gap-1.5 text-xs font-black text-emerald-800 hover:text-emerald-950 transition cursor-pointer"
          >
            <ArrowLeft size={16} />
            <span>DANH SÁCH THI</span>
          </button>
          <span className="text-[10px] text-slate-400 font-extrabold uppercase">KẾT QUẢ</span>
        </div>

        <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm text-center space-y-5">
          <div className="flex flex-col items-center gap-2">
            <div className={`p-4 rounded-full border ${attempt?.passed ? "bg-green-50 border-green-200 text-green-600" : "bg-red-50 border-red-200 text-red-600"}`}>
              <Award size={40} />
            </div>
            <h2 className="text-base font-black text-slate-800 leading-tight">Kết quả Sát hạch Chính quy</h2>
            <p className="text-[10px] text-slate-400 font-medium px-4">{selectedExam.title}</p>
          </div>

          {/* Score metrics bento-grid */}
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-left">
            <div>
              <p className="text-[9px] text-slate-400 uppercase font-extrabold tracking-wider">Tiêu chuẩn</p>
              <p className={`text-sm font-black mt-0.5 ${attempt?.passed ? "text-green-700" : "text-red-700"}`}>
                {attempt?.passed ? "ĐẠT YÊU CẦU" : "KHÔNG ĐẠT"}
              </p>
            </div>
            <div>
              <p className="text-[9px] text-slate-400 uppercase font-extrabold tracking-wider">Điểm tổng kết</p>
              <p className="text-sm font-black text-slate-800 mt-0.5">{attempt?.score} / 10</p>
            </div>
          </div>

          {/* Detail stats */}
          <div className="border border-slate-100 bg-slate-50/50 rounded-2xl p-3.5 text-[11px] text-left space-y-2 text-slate-500 font-medium">
            <div className="flex justify-between">
              <span>Thời điểm hoàn thành:</span>
              <span className="font-bold text-slate-800">
                {attempt?.submittedAt ? new Date(attempt.submittedAt).toLocaleString("vi-VN", { hour: 'numeric', minute: 'numeric', day: 'numeric', month: 'numeric' }) : "N/A"}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Số câu đúng:</span>
              <span className="font-bold text-green-700">{attempt?.correctCount} / {examQuestions.length}</span>
            </div>
            <div className="flex justify-between">
              <span>Số câu sai / bỏ trống:</span>
              <span className="font-bold text-red-700">{attempt?.wrongCount}</span>
            </div>
          </div>

          {/* Review exam review if allowed */}
          {selectedExam.allowReview && (
            <div className="text-left space-y-2.5 pt-2">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">RÀ SOÁT ĐÁP ÁN ĐÃ CHỌN:</h4>
              
              {allQuestions.filter(q => selectedExam.topicIds.includes(q.topicId)).map((q, idx) => {
                const userAns = attempt?.answers[q.id] || [];
                const isCorrect = q.correctAnswers.length === userAns.length &&
                  q.correctAnswers.every(v => userAns.includes(v));

                return (
                  <div key={q.id} className="p-3 bg-slate-50 border border-slate-100 rounded-2xl text-[11px] space-y-1.5">
                    <p className="font-bold text-slate-800 leading-normal">Câu {idx + 1}: {q.questionText}</p>
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 font-bold">Bài làm:</span>
                      <span className={isCorrect ? "text-green-800 font-bold" : "text-red-800 font-bold"}>
                        {userAns.map(v => q.options[v]).join(", ") || "(Chưa trả lời)"}
                      </span>
                      {isCorrect ? <CheckCircle size={12} className="text-green-600 shrink-0" /> : <AlertTriangle size={12} className="text-red-600 shrink-0" />}
                    </div>
                    <p className="text-[10px] text-slate-500 border-t border-slate-200/50 pt-1 leading-relaxed">
                      <strong>Lý luận chính trị:</strong> {q.explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          )}

          {/* Back trigger button */}
          <button
            onClick={handleBackToList}
            className="w-full py-3 bg-slate-800 hover:bg-slate-900 active:scale-95 text-white font-extrabold text-xs rounded-xl transition shadow cursor-pointer min-h-[44px]"
          >
            Trở lại danh sách các đợt thi
          </button>
        </div>
      </div>
    );
  }

  // DEFAULT VIEW: LIST OF EXAMS
  return (
    <div className="space-y-5" id="official-exam-tab-content">
      {/* Visual Header Banner */}
      <div className="bg-gradient-to-br from-red-800 via-rose-900 to-rose-950 p-5 rounded-[24px] text-white shadow-md flex items-center gap-3.5 relative overflow-hidden">
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none transform translate-y-3">
          <ClipboardList size={100} />
        </div>
        <div className="space-y-1">
          <span className="inline-block px-2 py-0.5 bg-yellow-400 text-slate-950 text-[9px] font-black rounded uppercase tracking-wide">
            Chính quy định kỳ
          </span>
          <h2 className="text-base font-black tracking-tight mt-1">Sát hạch chính trị viên</h2>
          <p className="text-[10px] text-red-100/90 leading-relaxed max-w-xs">
            Các kỳ thi chính thức dùng để chấm điểm thi đua, kiểm tra phẩm chất chính trị, kỷ luật quân đội và nhận thức lý luận cách mạng.
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">Danh sách đợt sát hạch</h3>

        {exams.length > 0 ? (
          <div className="space-y-3">
            {exams.map(exam => {
              const attempt = getUserAttempt(exam.id);
              const isAttempted = attempt !== undefined;
              const isExpired = exam.status === "expired" || new Date(exam.endDate) < new Date();

              return (
                <div
                  key={exam.id}
                  className="bg-white border border-slate-100 rounded-[24px] p-4.5 shadow-sm hover:border-red-200 transition flex flex-col justify-between relative overflow-hidden"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 font-black rounded-full text-[8px] uppercase tracking-wide border ${
                        isAttempted ? "bg-green-50 border-green-200 text-green-700" :
                        isExpired ? "bg-slate-100 border-slate-200 text-slate-500" : "bg-red-50 border-red-200 text-red-700 animate-pulse"
                      }`}>
                        {isAttempted ? "Đã nộp bài" : isExpired ? "Đã kết thúc" : "Đang mở đợt"}
                      </span>
                      <span className="text-[9px] text-slate-400 font-extrabold uppercase font-mono">
                        {exam.durationMinutes} phút • {exam.questionCount} câu
                      </span>
                    </div>

                    <h4 className="text-xs font-black text-slate-800 leading-snug">
                      {exam.title}
                    </h4>

                    <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                      {exam.description}
                    </p>

                    <p className="text-[9px] text-slate-400/95 font-bold">
                      Hạn thi: {new Date(exam.startDate).toLocaleDateString("vi-VN", { day: 'numeric', month: 'numeric' })} - {new Date(exam.endDate).toLocaleDateString("vi-VN", { day: 'numeric', month: 'numeric', year: '2-digit' })}
                    </p>
                  </div>

                  {/* Actions Row */}
                  <div className="mt-4 pt-3 border-t border-slate-50 flex items-center justify-between">
                    {isAttempted ? (
                      <div className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                        <span>Điểm số: <strong className="text-slate-800 font-black">{attempt.score}/10</strong></span>
                        <span className={`px-1.5 py-0.5 rounded-full text-[8px] font-black uppercase ${
                          attempt.passed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }`}>
                          {attempt.passed ? "Đạt" : "Hỏng"}
                        </span>
                      </div>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-bold">Chưa nộp bài thi</span>
                    )}

                    {isAttempted ? (
                      <button
                        onClick={() => {
                          setSelectedExam(exam);
                          setExamMode("result");
                        }}
                        className="py-2 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200/40 text-slate-600 font-extrabold text-[10px] rounded-xl transition cursor-pointer min-h-[36px]"
                      >
                        Xem bài làm & giải thích
                      </button>
                    ) : isExpired ? (
                      <button
                        disabled
                        className="py-2 px-3 bg-slate-50 text-slate-400 font-extrabold text-[10px] rounded-xl transition opacity-60 min-h-[36px]"
                      >
                        Hết hạn nộp
                      </button>
                    ) : (
                      <button
                        onClick={() => handleStartExam(exam)}
                        className="py-2.5 px-4 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-black text-[10px] uppercase rounded-xl transition shadow-sm flex items-center gap-1.5 cursor-pointer min-h-[36px]"
                        id={`btn-exam-start-${exam.id}`}
                      >
                        <span>Thi ngay</span>
                        <ChevronRight size={12} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-12 text-center text-slate-400 flex flex-col items-center gap-2 bg-white rounded-[24px] border border-dashed border-slate-200" id="exams-empty-state">
            <FileText size={32} className="text-slate-300" />
            <p className="text-xs font-bold text-slate-700">Không tìm thấy đợt sát hạch nào</p>
          </div>
        )}
      </div>
    </div>
  );
}
