import React, { useState, useRef, useEffect } from "react";
import { User, LearningTopic, AIChatMessage } from "../types";
import { Send, Sparkles, AlertCircle, MessageSquare, Trash2, HelpCircle, FileText, Compass } from "lucide-react";

interface AITutorProps {
  user: User;
  topics: LearningTopic[];
  activeTopicArg: any; // could be topic or custom scenario context
  onClearTopicArg: () => void;
}

export default function AITutor({ user, topics, activeTopicArg, onClearTopicArg }: AITutorProps) {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: "welcome",
      userId: user.id,
      role: "model",
      content: `Kính chào đồng chí **${user.fullName}**! Tôi là **AI Chính trị viên số** - Trợ lý ảo hỗ trợ học tập và phổ biến pháp luật quân sự.

Tôi có thể giúp đồng chí giải quyết những công việc sau:
1. **Giải thích các chuyên đề**: Lý luận chính trị, tư tưởng Hồ Chí Minh, truyền thống cách mạng địa phương.
2. **Làm rõ luật quốc phòng**: Nghĩa vụ quân sự 2015, Dân quân tự vệ 2019, quy tắc xử phạt kỷ luật quân đội.
3. **Phân giải tình huống**: Nhận diện thông tin xấu độc, giải quyết tranh chấp pháp luật đại chúng, ứng xử văn hóa quân nhân.
4. **Học tập thông minh**: Tóm tắt tài liệu, thiết kế kế hoạch ôn luyện tự lập, tạo các bộ câu hỏi ôn tập nhanh.

Đồng chí cần tôi hỗ trợ giải thích nội dung gì hôm nay?`,
      createdAt: new Date().toISOString()
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggested preset questions
  const presetQuestions = [
    {
      label: "Tóm tắt lý tưởng Cách mạng",
      prompt: "Hãy tóm tắt ngắn gọn mục tiêu cốt lõi của chuyên đề 'Kiên định lý tưởng cách mạng' và cho ví dụ thực tế."
    },
    {
      label: "Giải thích Tạm hoãn NVQS",
      prompt: "Các trường hợp nào được tạm hoãn gọi nhập ngũ nghĩa vụ quân sự theo Luật năm 2015?"
    },
    {
      label: "Xử lý thông tin xấu độc",
      prompt: "Khi phát hiện tài khoản mạng xã hội đăng bài bôi nhọ lãnh đạo quân đội, một chiến sĩ dân quân nên xử lý thế nào cho đúng?"
    },
    {
      label: "Kế hoạch tự học 7 ngày",
      prompt: "Lập cho tôi kế hoạch tự học Luật Dân quân tự vệ trong vòng 7 ngày, mỗi ngày 15 phút tập trung."
    }
  ];

  // Sync prop context from other tabs (e.g. "Ask AI about this topic")
  useEffect(() => {
    if (activeTopicArg) {
      const topicTitle = activeTopicArg.title || activeTopicArg.name || "Chuyên đề đang xem";
      const prompt = `Hãy tóm tắt cốt lõi, rút ra các gạch đầu dòng quan trọng cần nhớ và đưa ra 1 tình huống thực tế áp dụng cho chuyên đề: "${topicTitle}".`;
      setInputText(prompt);
      onClearTopicArg();
    }
  }, [activeTopicArg]);

  // Autoscroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const prompt = customPrompt || inputText;
    if (!prompt.trim() || loading) return;

    setErrorMsg("");
    setInputText("");

    // Add User message
    const userMsg: AIChatMessage = {
      id: "msg_" + Date.now(),
      userId: user.id,
      role: "user",
      content: prompt,
      createdAt: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: prompt,
          // Exclude welcome message to avoid breaking standard structure
          history: messages.slice(1).map(m => ({ role: m.role, content: m.content })),
        })
      });

      if (!response.ok) {
        throw new Error("Lỗi mạng khi kết nối máy chủ AI.");
      }

      const data = await response.json();
      
      const aiMsg: AIChatMessage = {
        id: "msg_ai_" + Date.now(),
        userId: user.id,
        role: "model",
        content: data.content,
        createdAt: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg("Không thể kết nối với AI Chính trị viên lúc này. Đồng chí vui lòng thử lại sau.");
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm("Đồng chí có muốn xóa toàn bộ lịch sử trò chuyện để bắt đầu phiên mới?")) {
      setMessages([
        {
          id: "welcome",
          userId: user.id,
          role: "model",
          content: `Đã dọn dẹp lịch sử trò chuyện. Tôi sẵn sàng hỗ trợ đồng chí giải đáp mọi nội dung lý luận giáo dục chính trị và quy định pháp luật học tập.`,
          createdAt: new Date().toISOString()
        }
      ]);
      setErrorMsg("");
    }
  };

  // Convert simple markdown-like text to nice HTML
  const formatMarkdownToJSX = (text: string) => {
    // Escape standard code tags or replace bold
    const lines = text.split("\n");
    return lines.map((line, idx) => {
      let styledLine = line;
      // replacement for bold markdown: **text**
      const boldRegex = /\*\*(.*?)\*\*/g;
      const parts = [];
      let lastIndex = 0;
      let match;

      while ((match = boldRegex.exec(line)) !== null) {
        if (match.index > lastIndex) {
          parts.push(line.substring(lastIndex, match.index));
        }
        parts.push(<strong key={match.index} className="font-bold text-slate-900">{match[1]}</strong>);
        lastIndex = boldRegex.lastIndex;
      }

      if (lastIndex < line.length) {
        parts.push(line.substring(lastIndex));
      }

      const content = parts.length > 0 ? parts : styledLine;

      if (line.startsWith("### ")) {
        return <h4 key={idx} className="text-xs font-bold text-emerald-900 mt-3 border-b border-emerald-100 pb-1 uppercase tracking-wider">{line.replace("### ", "")}</h4>;
      }
      if (line.startsWith("* ") || line.startsWith("- ")) {
        return <li key={idx} className="ml-4 list-disc text-xs text-slate-700 leading-relaxed mt-1">{line.substring(2)}</li>;
      }
      if (/^\d+\.\s/.test(line)) {
        return <p key={idx} className="text-xs text-slate-700 leading-relaxed pl-2 mt-1.5 font-medium">{line}</p>;
      }
      return <p key={idx} className="text-xs text-slate-700 leading-relaxed mt-1">{content}</p>;
    });
  };

  return (
    <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden flex flex-col h-[78vh]" id="ai-chat-screen-layout">
      {/* Chat Title bar */}
      <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 px-4 py-3 flex items-center justify-between text-white shrink-0">
        <div className="flex items-center gap-2">
          <div className="bg-white/10 p-1.5 rounded-full border border-white/20">
            <Sparkles size={16} className="text-yellow-400 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs md:text-sm font-bold">Trợ lý AI</h3>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping" />
              <span className="text-[9px] text-emerald-200">Trợ lý AI trực tuyến • Mô hình 3.5-Flash</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleClearHistory}
          className="p-1.5 text-emerald-100 hover:text-white hover:bg-white/10 rounded-lg transition"
          title="Xóa lịch sử trò chuyện"
        >
          <Trash2 size={16} />
        </button>
      </div>

      {/* Chat messages viewport */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50" id="ai-messages-viewport">
        {messages.map(msg => {
          const isAI = msg.role === "model";
          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 max-w-[90%] ${isAI ? "mr-auto" : "ml-auto flex-row-reverse"}`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-[9px] shrink-0 ${
                isAI ? "bg-emerald-800 text-white" : "bg-slate-800 text-white"
              }`}>
                {isAI ? "AI" : "ĐC"}
              </div>
              <div className={`p-3.5 rounded-2xl text-[11px] space-y-1 leading-relaxed border shadow-sm ${
                isAI 
                  ? "bg-white border-slate-100 text-slate-800 rounded-tl-none" 
                  : "bg-emerald-800 border-emerald-900 text-white rounded-tr-none"
              }`}>
                {isAI ? (
                  formatMarkdownToJSX(msg.content)
                ) : (
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-2.5 max-w-[85%] mr-auto">
            <div className="w-6 h-6 rounded-full bg-emerald-800 text-white flex items-center justify-center font-black text-[9px] shrink-0">
              AI
            </div>
            <div className="bg-white border border-slate-100 p-3 rounded-2xl rounded-tl-none text-[11px] text-slate-500 shadow-sm flex items-center gap-2">
              <div className="flex space-x-1 shrink-0">
                <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>Chính trị viên số đang gõ...</span>
            </div>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-xl flex items-center gap-1.5 max-w-md mx-auto">
            <AlertCircle size={16} className="text-red-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Chips / Presets for fast input */}
      {!loading && (
        <div className="px-3.5 py-2 bg-slate-50 border-t border-slate-100 shrink-0" id="ai-preset-chips-box">
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {presetQuestions.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(undefined, q.prompt)}
                className="px-2.5 py-1 bg-white border border-slate-200/60 rounded-full text-[9px] font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-900 hover:border-emerald-200 transition shrink-0 cursor-pointer shadow-sm"
              >
                {q.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input panel & Safety Disclaimer */}
      <div className="p-3 bg-white border-t border-slate-100 shrink-0 space-y-2">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={loading}
            placeholder="Hỏi về nghĩa vụ quân sự, điều lệnh, kỷ luật đơn vị..."
            className="flex-1 px-4 py-2 text-xs md:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || loading}
            className="p-2.5 bg-emerald-800 hover:bg-emerald-900 disabled:opacity-40 text-white rounded-xl transition shadow shrink-0 flex items-center justify-center cursor-pointer"
            id="btn-ai-send"
          >
            <Send size={16} />
          </button>
        </form>

        {/* MANDATORY AI SAFETY DISCLAIMER FOOTER */}
        <p className="text-[9px] text-slate-400 leading-normal text-center italic font-medium px-4">
          “AI hỗ trợ học tập và tham khảo. Khi áp dụng vào công việc chính thức, cần đối chiếu văn bản, hướng dẫn và chỉ đạo có thẩm quyền.”
        </p>
      </div>
    </div>
  );
}
