import React, { useState } from "react";
import { User, UserRole, AccountStatus, Unit } from "../types";
import { authService } from "../services/authService";
import { Shield, User as UserIcon, Phone, Mail, Home, Key, CheckCircle, AlertTriangle } from "lucide-react";

interface AuthProps {
  currentUser: User | null;
  onLogin: (user: User | null) => void;
  onRegister: (userData: any) => void;
  units: Unit[];
}

export default function Auth({ currentUser, onLogin, onRegister, units }: AuthProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // Register state
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regUnit, setRegUnit] = useState(units[1]?.id || "u2");
  const [regRole, setRegRole] = useState<UserRole>(UserRole.MEMBER);
  const [regPassword, setRegPassword] = useState("");
  const [regConfirmPassword, setRegConfirmPassword] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!emailOrPhone || !password) {
      setError("Vui lòng điền đầy đủ email/số điện thoại và mật khẩu.");
      return;
    }

    authService.login(emailOrPhone, password)
      .then((res) => {
        onLogin(res.user);
      })
      .catch((err: any) => {
        setError(err.message || "Thông tin đăng nhập không chính xác hoặc lỗi kết nối.");
      });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!regName || !regEmail || !regPhone || !regPassword) {
      setError("Vui lòng điền đầy đủ các thông tin bắt buộc.");
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setError("Mật khẩu xác nhận không trùng khớp.");
      return;
    }

    authService.register({
      fullName: regName,
      email: regEmail,
      phone: regPhone,
      unitId: regUnit,
      password: regPassword,
    })
      .then((res) => {
        setSuccessMsg(res.message || "Đăng ký thành công! Tài khoản của đồng chí đang chờ chỉ huy phê duyệt.");
        setIsRegistering(false);
        // reset fields
        setRegName("");
        setRegEmail("");
        setRegPhone("");
        setRegPassword("");
        setRegConfirmPassword("");
      })
      .catch((err: any) => {
        setError(err.message || "Đăng ký thất bại.");
      });
  };

  const handleRequiredPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!password || !newPassword) {
      setError("Vui lòng nhập mật khẩu tạm thời và mật khẩu mới.");
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError("Mật khẩu mới và xác nhận mật khẩu không trùng khớp.");
      return;
    }
    try {
      const res = await authService.changePassword(password, newPassword);
      setPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      onLogin(res.user);
    } catch (err: any) {
      setError(err.message || "Không thể đổi mật khẩu.");
    }
  };


  if (currentUser && currentUser.accountStatus === AccountStatus.PENDING) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 py-8 text-center" id="auth-pending-screen">
        <div className="p-4 bg-amber-50 text-amber-800 rounded-full mb-4 animate-pulse">
          <AlertTriangle size={48} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Đang chờ phê duyệt</h2>
        <p className="text-slate-600 max-w-md mb-6 text-sm">
          Tài khoản của đồng chí <strong>{currentUser.fullName}</strong> đã được đăng ký thành công vào đơn vị <strong>{units.find(u => u.id === currentUser.unitId)?.name || currentUser.unitId}</strong> với vai trò đề xuất: <strong>{currentUser.role === UserRole.MEMBER ? "Học viên (Chiến sĩ)" : currentUser.role}</strong>.
        </p>
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left max-w-md mb-6 w-full text-xs text-slate-500">
          <p className="font-semibold text-slate-700 mb-1">Quy trình phê duyệt:</p>
          <ol className="list-decimal pl-4 space-y-1">
            <li>Thông tin đăng ký được chuyển đến Chỉ huy / Chính trị viên đơn vị.</li>
            <li>Ban chỉ huy xác thực danh tính và quân số của đồng chí.</li>
            <li>Hệ thống kích hoạt tài khoản chính thức trong vòng 12-24h.</li>
          </ol>
        </div>
        <button
          onClick={() => onLogin(null)}
          className="px-6 py-2 bg-slate-800 text-white font-medium rounded-lg text-sm hover:bg-slate-700 transition"
          id="btn-back-to-login"
        >
          Quay lại Đăng nhập
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto my-8 bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100" id="auth-container">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-emerald-800 to-emerald-950 px-6 py-8 text-white text-center relative">
        <div className="mx-auto w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-3 border border-white/20">
          <Shield className="text-amber-400" size={32} />
        </div>
        <h1 className="text-xl font-bold tracking-tight">BAN CHỈ HUY PTKV3</h1>
        <p className="text-[11px] text-emerald-200/90 mt-1 max-w-xs mx-auto">
          Trung tâm Giáo dục Chính trị số
        </p>
      </div>

      <div className="p-6">
        {successMsg && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-800 text-xs rounded-lg flex items-start gap-2">
            <CheckCircle className="shrink-0 text-green-600 mt-0.5" size={16} />
            <span>{successMsg}</span>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-lg flex items-start gap-2">
            <AlertTriangle className="shrink-0 text-red-600 mt-0.5" size={16} />
            <span>{error}</span>
          </div>
        )}

        {currentUser?.mustChangePassword ? (
          <form onSubmit={handleRequiredPasswordChange} className="space-y-4" id="required-password-change-form">
            <h2 className="text-lg font-semibold text-slate-800 border-b pb-2 mb-4">Đổi mật khẩu lần đầu</h2>
            <p className="text-xs text-slate-600">
              Tài khoản được tạo bằng mật khẩu tạm thời. Đồng chí cần đổi mật khẩu trước khi tiếp tục.
            </p>
            <input
              type="password"
              placeholder="Mật khẩu tạm thời"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
              required
            />
            <input
              type="password"
              placeholder="Mật khẩu mới (ít nhất 8 ký tự)"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
              minLength={8}
              required
            />
            <input
              type="password"
              placeholder="Xác nhận mật khẩu mới"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600"
              minLength={8}
              required
            />
            <button type="submit" className="w-full py-2 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-medium rounded-lg text-sm shadow transition">
              Đổi mật khẩu và tiếp tục
            </button>
            <button type="button" onClick={() => onLogin(null)} className="w-full text-xs text-slate-500 hover:underline">
              Quay lại đăng nhập
            </button>
          </form>
        ) : !isRegistering ? (
          /* LOGIN FORM */
          <form onSubmit={handleLogin} className="space-y-4" id="login-form">
            <h2 className="text-lg font-semibold text-slate-800 border-b pb-2 mb-4">Đăng nhập Hệ thống</h2>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Email hoặc Số điện thoại</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <UserIcon size={16} />
                </span>
                <input
                  type="text"
                  placeholder="minh.levan@gmail.com hoặc 0901234567"
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Mật khẩu</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Key size={16} />
                </span>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <label className="flex items-center gap-1.5 text-slate-500 cursor-pointer">
                <input type="checkbox" className="rounded border-slate-300 text-emerald-600" defaultChecked />
                <span>Ghi nhớ đăng nhập</span>
              </label>
              <button
                type="button"
                onClick={() => setError("Vui lòng liên hệ Trợ lý Chính trị viên/Quản trị viên để đặt lại mật khẩu.")}
                className="text-emerald-700 hover:underline"
              >
                Quên mật khẩu?
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-medium rounded-lg text-sm shadow transition"
              id="btn-login-submit"
            >
              Vào hệ thống
            </button>

            <div className="text-center text-xs text-slate-500 pt-2">
              Chưa có tài khoản?{" "}
              <button
                type="button"
                onClick={() => {
                  setIsRegistering(true);
                  setError("");
                  setSuccessMsg("");
                }}
                className="text-emerald-700 font-semibold hover:underline"
                id="btn-switch-register"
              >
                Đăng ký tài khoản mới
              </button>
            </div>
          </form>
        ) : (
          /* REGISTER FORM */
          <form onSubmit={handleRegister} className="space-y-3.5" id="register-form">
            <h2 className="text-lg font-semibold text-slate-800 border-b pb-2 mb-3">Đăng ký tài khoản</h2>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Họ và tên quân nhân / công chức *</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <UserIcon size={16} />
                </span>
                <input
                  type="text"
                  placeholder="Nhập họ tên đầy đủ"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Số điện thoại *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Phone size={14} />
                  </span>
                  <input
                    type="tel"
                    placeholder="09..."
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Địa chỉ Email *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Mail size={14} />
                  </span>
                  <input
                    type="email"
                    placeholder="dongchi@gmail.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Đơn vị / Tổ dân quân *</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Home size={14} />
                  </span>
                  <select
                    value={regUnit}
                    onChange={(e) => setRegUnit(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition appearance-none"
                  >
                    {units.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Vai trò đề xuất *</label>
                <select
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as UserRole)}
                  className="w-full px-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                >
                  <option value={UserRole.MEMBER}>Chiến sĩ / Học viên</option>
                  <option value={UserRole.INSTRUCTOR}>Giáo viên / Giảng viên</option>
                  <option value={UserRole.POLITICAL_OFFICER}>Chính trị viên / Chỉ huy</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Mật khẩu *</label>
                <input
                  type="password"
                  placeholder="Mật khẩu"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  className="w-full px-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Xác nhận mật khẩu *</label>
                <input
                  type="password"
                  placeholder="Nhập lại"
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  className="w-full px-3 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-medium rounded-lg text-sm shadow transition mt-2"
              id="btn-register-submit"
            >
              Gửi yêu cầu đăng ký
            </button>

            <div className="text-center text-xs text-slate-500 pt-1">
              Đã có tài khoản?{" "}
              <button
                type="button"
                onClick={() => {
                  setIsRegistering(false);
                  setError("");
                  setSuccessMsg("");
                }}
                className="text-emerald-700 font-semibold hover:underline"
                id="btn-switch-login"
              >
                Đăng nhập ngay
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
}
