import React, { useState } from "react";
import { User, LearningTopic, LearningProgress, QuizAttempt, ExamAttempt, LearningStatus, Unit } from "../types";
import { Award, TrendingUp, Calendar, ClipboardList, ChevronRight, Star, ShieldAlert, Settings, Moon, Bell, LogOut, CheckCircle, RefreshCw, Sparkles, BookOpen } from "lucide-react";
import { RankingEntry } from "../services/reportService";
import { legacyReviewData } from "../data/cdsLegacyData";

interface ResultsAndRankingProps {
  user: User;
  topics: LearningTopic[];
  progress: LearningProgress[];
  quizAttempts: QuizAttempt[];
  examAttempts: ExamAttempt[];
  units: Unit[];
  rankingEntries: RankingEntry[];
  onNavigate: (tab: string, arg?: any) => void;
}

export default function ResultsAndRanking({
  user,
  topics,
  progress,
  quizAttempts,
  examAttempts,
  units,
  rankingEntries,
  onNavigate
}: ResultsAndRankingProps) {
  // Tabs: profile, leaderboard
  const [subTab, setSubTab] = useState<"profile" | "leaderboard">("profile");
  const [leaderboardScope, setLeaderboardScope] = useState<"overall" | "unit">("overall");
  
  // Interactive settings state
  const [darkMode, setDarkMode] = useState(false);
  const [notificationEnabled, setNotificationEnabled] = useState(true);
  const [dailyReminder, setDailyReminder] = useState(true);

  // User metrics calculation
  const userProgress = progress.filter(p => p.userId === user.id);
  const userQuizAttempts = quizAttempts.filter(q => q.userId === user.id);
  const userExamAttempts = examAttempts.filter(e => e.userId === user.id);

  const completedCount = userProgress.filter(p => p.status === LearningStatus.COMPLETED).length;
  const inProgressCount = userProgress.filter(p => p.status === LearningStatus.IN_PROGRESS).length;
  const needReviewCount = userProgress.filter(p => p.status === LearningStatus.NEED_REVIEW).length;

  const totalRequired = topics.filter(t => t.required).length;
  const completedRequired = topics.filter(t => {
    if (!t.required) return false;
    const p = userProgress.find(pr => pr.topicId === t.id);
    return p && p.status === LearningStatus.COMPLETED;
  }).length;

  const reqCompletionPercent = totalRequired > 0 ? Math.round((completedRequired / totalRequired) * 100) : 100;

  // Average quiz scores
  const totalQuizScore = userQuizAttempts.reduce((acc, q) => acc + q.score, 0);
  const avgQuizScore = userQuizAttempts.length > 0 ? Number((totalQuizScore / userQuizAttempts.length).toFixed(1)) : 0;

  // Exams passed count
  const examsPassedCount = userExamAttempts.filter(e => e.passed).length;

  // Weak topics detection & recommendations
  const getWeakTopics = () => {
    // Topics marked as NEED_REVIEW or where quiz score < 6
    const weakList: { topic: LearningTopic; reason: string }[] = [];
    
    topics.forEach(topic => {
      const p = userProgress.find(pr => pr.topicId === topic.id);
      const quizzesForTopic = userQuizAttempts.filter(q => q.topicId === topic.id);
      const lowestScore = quizzesForTopic.length > 0 ? Math.min(...quizzesForTopic.map(q => q.score)) : null;

      if (p && p.status === LearningStatus.NEED_REVIEW) {
        weakList.push({ topic, reason: "Được đánh dấu cần nghiên cứu sâu thêm" });
      } else if (lowestScore !== null && lowestScore < 6) {
        weakList.push({ topic, reason: `Điểm trắc nghiệm thấp nhất đạt ${lowestScore}/10` });
      }
    });

    return weakList.slice(0, 2); // Show top 2 weak topics
  };

  const weakTopics = getWeakTopics();

  const leaderboard = rankingEntries.map(entry => {
      let badgeLabel = "Chiến sĩ Tập sự";
      if (entry.points > 120) badgeLabel = "Chuyên gia Lý luận";
      else if (entry.points > 80) badgeLabel = "Học viên Ưu tú";
      else if (entry.points > 40) badgeLabel = "Chiến sĩ Gương mẫu";
      return { ...entry, badge: badgeLabel };
    });
  const currentRankEntry = leaderboard.find(e => e.userId === user.id);

  const filteredLeaderboard = leaderboardScope === "unit"
    ? leaderboard.filter(e => {
        return e.unitId === user.unitId;
      })
    : leaderboard;

  // SVG circular progress parameters
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (reqCompletionPercent / 100) * circumference;

  return (
    <div className="space-y-4" id="results-and-ranking-tab">
      
      {/* Dynamic Sub-tab selector */}
      <div className="bg-white border border-slate-100 rounded-2xl p-1 shadow-sm flex text-center font-bold text-xs shrink-0">
        <button
          onClick={() => setSubTab("profile")}
          className={`flex-1 py-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 min-h-[44px] ${
            subTab === "profile" 
              ? "bg-emerald-800 text-white shadow" 
              : "text-slate-500 hover:bg-slate-50"
          }`}
        >
          <Award size={14} />
          <span>Hồ sơ & Đạt được</span>
        </button>
        <button
          onClick={() => setSubTab("leaderboard")}
          className={`flex-1 py-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 min-h-[44px] ${
            subTab === "leaderboard" 
              ? "bg-emerald-800 text-white shadow" 
              : "text-slate-500 hover:bg-slate-50"
          }`}
        >
          <Star size={14} />
          <span>Bảng vàng thi đua</span>
        </button>
      </div>

      {subTab === "profile" ? (
        <div className="space-y-4 animate-fade-in" id="profile-subtab-container">
          
          {/* MD3 Profile Header card */}
          <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm flex items-center gap-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-emerald-500/10 to-emerald-800/5 rounded-full -mr-8 -mt-8" />
            
            {/* User Avatar Badge with initial letters */}
            <div className="w-14 h-14 bg-emerald-800 text-white font-black text-lg rounded-2xl flex items-center justify-center shrink-0 shadow-md">
              {user.fullName.split(" ").pop()?.substring(0, 2).toUpperCase()}
            </div>

            <div className="min-w-0">
              <span className="px-1.5 py-0.5 bg-yellow-400 text-slate-950 font-black rounded text-[8px] uppercase tracking-wide">
                {currentRankEntry?.badge || "Đồng chí"}
              </span>
              <h2 className="text-sm font-black text-slate-800 mt-1 leading-tight">{user.fullName}</h2>
              <p className="text-[10px] text-slate-400 font-extrabold uppercase mt-0.5 truncate">
                ĐƠN VỊ: {units.find(u => u.id === user.unitId)?.name || "Yên Thế"}
              </p>
            </div>
          </div>

          {/* Bento Grid: Circular progress & Learning Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Required Lesson Progress Circular Circle */}
            <div className="bg-white border border-slate-100 rounded-[24px] p-4.5 shadow-sm flex items-center justify-between gap-4">
              <div className="space-y-1.5">
                <p className="text-[9px] font-black tracking-wider uppercase text-slate-400">CHỦ ĐỀ BẮT BUỘC</p>
                <h3 className="text-xs font-black text-slate-800 leading-tight">Hoàn thành bài</h3>
                <p className="text-[10px] text-slate-400 leading-tight">Đã học {completedRequired} trên tổng số {totalRequired} bài bắt buộc chỉ định.</p>
              </div>

              {/* SVG Ring charts */}
              <div className="relative w-16 h-16 shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 80 80">
                  <circle
                    cx="40"
                    cy="40"
                    r={radius}
                    className="text-slate-100"
                    strokeWidth="8"
                    stroke="currentColor"
                    fill="transparent"
                  />
                  <circle
                    cx="40"
                    cy="40"
                    r={radius}
                    className="text-emerald-800"
                    strokeWidth="8"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-black text-slate-800">{reqCompletionPercent}%</span>
                </div>
              </div>
            </div>

            {/* Quick stats grid */}
            <div className="bg-white border border-slate-100 rounded-[24px] p-4.5 shadow-sm grid grid-cols-2 gap-3.5">
              <div className="space-y-0.5">
                <span className="text-[8px] font-black uppercase tracking-wider text-slate-400">TỔNG ĐIỂM THI ĐUA</span>
                <p className="text-sm font-black text-slate-800">{currentRankEntry?.points || 0} Điểm</p>
                <p className="text-[9px] text-slate-400">Hạng {currentRankEntry?.rank || "N/A"} toàn phân đội</p>
              </div>
              <div className="space-y-0.5">
                <span className="text-[8px] font-black uppercase tracking-wider text-slate-400">LUYỆN TẬP</span>
                <p className="text-sm font-black text-slate-800">{avgQuizScore} / 10</p>
                <p className="text-[9px] text-slate-400">Trung bình {userQuizAttempts.length} lượt luyện tập</p>
              </div>
            </div>

          </div>

          {/* Weak Topics & Smart Recommendations Section */}
          <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm space-y-3">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <ShieldAlert size={14} className="text-red-500 shrink-0" />
              <span>Chủ đề cần ôn luyện & Kiến nghị AI</span>
            </h4>

            {weakTopics.length > 0 ? (
              <div className="space-y-2.5">
                {weakTopics.map(item => (
                  <div key={item.topic.id} className="p-3 bg-red-50/50 border border-red-100 rounded-2xl text-xs space-y-2">
                    <div>
                      <p className="font-bold text-slate-800 leading-snug">{item.topic.title}</p>
                      <p className="text-[9px] text-red-700 font-bold mt-0.5">{item.reason}</p>
                    </div>
                    <button
                      onClick={() => onNavigate("aitutor", item.topic)}
                      className="inline-flex items-center gap-1 text-[9px] font-black uppercase text-emerald-800 hover:text-emerald-950 bg-white px-2.5 py-1 rounded-full shadow-sm border border-emerald-100 cursor-pointer"
                    >
                      <Sparkles size={10} />
                      <span>Trợ lý giải thích lý luận này</span>
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-green-50/50 border border-green-100 text-center text-xs space-y-2 text-green-800 font-bold">
                <CheckCircle size={20} className="mx-auto text-green-600" />
                <p>Tuyệt vời! Bản lĩnh chính trị xuất sắc, không phát hiện lỗ hổng lý thuyết.</p>
              </div>
            )}
          </div>

          {/* Detailed Logs Accordion Card (Quiz & Official exam attempts) */}
          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Lịch sử bài kiểm tra đã nộp</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Quiz Log */}
              <div className="bg-white border border-slate-100 rounded-[24px] p-4 shadow-sm space-y-2">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-50 pb-1.5 flex items-center gap-1.5">
                  <ClipboardList size={12} className="text-emerald-800" />
                  <span>Trắc nghiệm nhanh ({userQuizAttempts.length})</span>
                </p>
                {userQuizAttempts.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {userQuizAttempts.map(attempt => {
                      const topic = topics.find(t => t.id === attempt.topicId);
                      return (
                        <div key={attempt.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl text-[11px] flex justify-between items-center gap-2">
                          <span className="font-bold text-slate-800 truncate leading-none">{topic?.title || "Ôn tập tổng hợp"}</span>
                          <span className={`px-2 py-0.5 rounded-full font-black text-[9px] uppercase shrink-0 ${
                            attempt.score >= 6 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                          }`}>
                            {attempt.score}/10
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-center text-[10px] text-slate-400 py-4">Chưa thực hiện tự luyện nào</p>
                )}
              </div>

              {/* Official Exam Log */}
              <div className="bg-white border border-slate-100 rounded-[24px] p-4 shadow-sm space-y-2">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-50 pb-1.5 flex items-center gap-1.5">
                  <Calendar size={12} className="text-red-700" />
                  <span>Sát hạch chính thức ({userExamAttempts.length})</span>
                </p>
                {userExamAttempts.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {userExamAttempts.map(attempt => (
                      <div key={attempt.id} className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl text-[11px] flex justify-between items-center gap-2">
                        <span className="font-bold text-slate-800 truncate leading-none">Chính trị viên đợt 1</span>
                        <span className={`px-2 py-0.5 rounded-full font-black text-[9px] uppercase shrink-0 ${
                          attempt.passed ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }`}>
                          {attempt.score}/10 {attempt.passed ? "Đạt" : "Hỏng"}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-[10px] text-slate-400 py-4">Chưa có kết quả chính quy</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm space-y-3">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-50 pb-2">
              Xem lại & Giải thích
            </h4>
            <div className="space-y-2">
              {legacyReviewData.map(item => (
                <div key={item.id} className="p-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs">
                  <p className="font-black text-slate-800">{item.title}</p>
                  <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">{item.description}</p>
                  <p className="text-[9px] text-red-700 font-bold mt-1">Nguồn CDS: {item.sourcePage}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Simulated MD3 App settings & Dark mode */}
          <div className="bg-white border border-slate-100 rounded-[24px] p-5 shadow-sm space-y-3.5">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-50 pb-2">
              <Settings size={14} className="text-slate-500 shrink-0" />
              <span>Thiết lập ứng dụng quân nhân</span>
            </h4>

            <div className="space-y-3">
              {/* Dark mode toggle */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Moon size={14} className="text-slate-400" />
                  <span className="font-bold text-slate-700">Chế độ hiển thị tối</span>
                </div>
                <button
                  type="button"
                  onClick={() => setDarkMode(!darkMode)}
                  className={`w-9 h-5 rounded-full p-0.5 transition cursor-pointer ${darkMode ? "bg-emerald-800" : "bg-slate-200"}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${darkMode ? "transform translate-x-4" : ""}`} />
                </button>
              </div>

              {/* Notification toggle */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Bell size={14} className="text-slate-400" />
                  <span className="font-bold text-slate-700">Thông báo từ ban chỉ huy</span>
                </div>
                <button
                  type="button"
                  onClick={() => setNotificationEnabled(!notificationEnabled)}
                  className={`w-9 h-5 rounded-full p-0.5 transition cursor-pointer ${notificationEnabled ? "bg-emerald-800" : "bg-slate-200"}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${notificationEnabled ? "transform translate-x-4" : ""}`} />
                </button>
              </div>

              {/* Daily Reminder toggle */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <BookOpen size={14} className="text-slate-400" />
                  <span className="font-bold text-slate-700">Nhắc nhở học tập hàng ngày</span>
                </div>
                <button
                  type="button"
                  onClick={() => setDailyReminder(!dailyReminder)}
                  className={`w-9 h-5 rounded-full p-0.5 transition cursor-pointer ${dailyReminder ? "bg-emerald-800" : "bg-slate-200"}`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${dailyReminder ? "transform translate-x-4" : ""}`} />
                </button>
              </div>
            </div>
          </div>

        </div>
      ) : (
        <div className="space-y-4 animate-fade-in" id="leaderboard-subtab-container">
          
          {/* Header & Leaderboard scale scope switcher */}
          <div className="bg-white border border-slate-100 rounded-[24px] p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase">Thi đua toàn quân</h3>
                <p className="text-[10px] text-slate-400 mt-0.5">Xếp hạng dựa trên nhận thức lý luận và chuyên đề học tập.</p>
              </div>

              {/* Scope filter chips */}
              <div className="flex gap-1 bg-slate-100 p-1 rounded-xl text-[9px] font-black uppercase tracking-wide">
                <button
                  onClick={() => setLeaderboardScope("overall")}
                  className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition ${
                    leaderboardScope === "overall" ? "bg-white text-slate-800 shadow-sm" : "text-slate-400"
                  }`}
                >
                  Cả đơn vị
                </button>
                <button
                  onClick={() => setLeaderboardScope("unit")}
                  className={`px-2.5 py-1.5 rounded-lg cursor-pointer transition ${
                    leaderboardScope === "unit" ? "bg-white text-slate-800 shadow-sm" : "text-slate-400"
                  }`}
                >
                  Cấp Phân Đội
                </button>
              </div>
            </div>
          </div>

          {/* Leaderboard mobile scroll list */}
          <div className="space-y-2.5">
            {filteredLeaderboard.map((entry) => {
              const isSelf = entry.userId === user.id;
              
              return (
                <div
                  key={entry.userId}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 text-xs transition ${
                    isSelf
                      ? "bg-amber-50 border-amber-300 shadow-sm font-bold scale-101"
                      : "bg-white border-slate-100 hover:border-slate-200 shadow-sm"
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    
                    {/* Rank Badge numbering indicator */}
                    <span className={`w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center shrink-0 border ${
                      entry.rank === 1 ? "bg-yellow-400 border-yellow-500 text-slate-900" :
                      entry.rank === 2 ? "bg-slate-200 border-slate-300 text-slate-700" :
                      entry.rank === 3 ? "bg-amber-600 border-amber-700 text-white" : "bg-slate-50 border-slate-100 text-slate-400"
                    }`}>
                      {entry.rank}
                    </span>

                    {/* Member profile image placeholder */}
                    <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-100 font-extrabold text-[10px] flex items-center justify-center shrink-0">
                      {entry.fullName.split(" ").pop()?.substring(0, 2).toUpperCase()}
                    </div>

                    <div className="min-w-0">
                      <p className="font-black text-slate-800 flex items-center gap-1 text-[11px]">
                        <span className="truncate">{entry.fullName}</span>
                        {isSelf && (
                          <span className="px-1.5 py-0.2 bg-amber-200 text-amber-950 rounded text-[7px] font-black uppercase shrink-0">
                            Tôi
                          </span>
                        )}
                      </p>
                      <p className="text-[9px] text-slate-400 truncate font-extrabold uppercase mt-0.5">
                        {entry.unitName} • {entry.badge}
                      </p>
                    </div>
                  </div>

                  {/* Points breakdown */}
                  <div className="text-right shrink-0">
                    <p className="font-black text-slate-800 text-xs">{entry.points} pts</p>
                    <p className="text-[9px] text-slate-400 font-extrabold uppercase mt-0.5">Đã học: {entry.completionRate}%</p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

    </div>
  );
}
